import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class AlertToastFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_alert_toast, container, false);

        Button btnAlert = view.findViewById(R.id.btnShowAlert);
        Button btnToast = view.findViewById(R.id.btnShowToast);

        btnAlert.setOnClickListener(v -> showAlertDialog());
        btnToast.setOnClickListener(v -> showToast());

        return view;
    }

    private void showAlertDialog() {
        new AlertDialog.Builder(getActivity())
                .setTitle("Contoh Alert")
                .setMessage("Ini adalah Alert Dialog dari Tab 1")
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void showToast() {
        Toast.makeText(getActivity(), "Ini Toast dari Tab 1", Toast.LENGTH_SHORT).show();
    }
}